var myChart = echarts.init(document.getElementById('main'));



option = {
    tooltip: {
        trigger: 'axis'
    },

}

myChart.setOption(option);